(function() {
    'use strict';

    angular
        .module('JHipsterRegistryApp')
        .constant('paginationConstants', {
            'itemsPerPage': 20
        });
})();
