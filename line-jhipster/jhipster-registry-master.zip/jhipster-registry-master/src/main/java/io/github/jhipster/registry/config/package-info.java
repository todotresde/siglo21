/**
 * Spring Framework configuration files.
 */
package io.github.jhipster.registry.config;
